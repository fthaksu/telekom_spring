package com.works.java8New;

import lombok.Data;

import java.util.Random;

@Data
public class Customer {

    private int id;
    private Random status;
    private String name;

}
