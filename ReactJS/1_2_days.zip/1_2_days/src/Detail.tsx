import React from 'react';

function Detail() {
  return (
    <>
      <h1>Welcome Detail</h1>
    </>
  );
}

export default Detail;
