import React from 'react';

function App() {
  return (
    <>
      <h1>Welcome App</h1>
      <a href='/product'>Goto Product</a>
    </>
  );
}

export default App;
