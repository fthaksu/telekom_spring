export interface INote {
    id: number,
    title: string,
    detail: string
}