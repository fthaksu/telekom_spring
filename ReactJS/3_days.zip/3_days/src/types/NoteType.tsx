export enum NoteType {

    NOTE_ADD="NOTE_ADD",
    NOTE_LIST="NOTE_LIST",
    NOTE_DELETE="NOTE_DELETE"

}