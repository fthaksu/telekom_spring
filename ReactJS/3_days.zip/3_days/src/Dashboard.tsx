import React from 'react'

function Dashboard() {
    return (
        <div>
            <h1>Welcome DahsBoard</h1>
        </div>
    )
}

export default Dashboard
