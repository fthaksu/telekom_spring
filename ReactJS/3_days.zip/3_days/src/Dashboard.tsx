import React, { useEffect } from 'react'
import { isLogin } from './Util'

function Dashboard() {

    return (
        <div>
            <h1>Welcome DahsBoard</h1>
        </div>
    )
}

export default Dashboard
