package com.works.useprofile;

import org.springframework.stereotype.Component;

@Component
public interface IConfig  {

    Config call();

}
