package com.works.useprofile;

import lombok.Data;

@Data
public class Config {

    private String apiKey;
    private int rowCount;
    private String ip;

}
