package com.works.utils;

public enum REnum {

    status, message, result, errors;

}
